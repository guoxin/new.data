load("new.Rdata")
load("report.Rdata")
TheThreshold <- (1 - log(500)/log(15000))
f <- function(x){
    appear.length <- 5
    the.value <- paste(signif(as.double(x), digits = appear.length))
    #computing how many zeros should be added
    temp <- unlist(strsplit(the.value, split = "\\."))
    if(length(temp)<2){#handle the integers
        the.value <- paste(the.value, ".", sep = "")
        temp[2] <- ""
    }
    if(nchar(temp[2]) < appear.length){
        z.str <- paste(rep("0", appear.length - nchar(temp[2])), collapse = "")
        the.value <- paste(the.value, z.str, sep = "")
    }
    the.value
}
theAlleles <- names(newData$allele.set)
weights <- double(length(theAlleles))
names(weights) <- theAlleles
longEnough <- (nchar(newData$peptide.list)>8.5)
w.rmse.me <- w.auc.me <- a.rmse.me <- a.auc.me <- w.rmse.N <- w.auc.N <- a.rmse.N <- a.auc.N <- 0
system("rm -rf midCodes.txt")
getAUC.guoxin <- function(predicted, realValue, threshold = TheThreshold){
    AN <- (realValue <= threshold)
    AP <- (!AN)
    compare <- matrix(predicted[AP], ncol = sum(AN), nrow = sum(AP))
    compare <- sweep(x = compare, MARGIN = 2, 
        STATS = predicted[AN], FUN = "-", check.margin = TRUE)
    auc0 <- mean(compare > 0)
    return(max(auc0, 1 - auc0))
}
getRMSE <- function(predicted, realValue){
    return(sqrt(mean( (predicted - realValue)^2 )))
}

for(nm in sort(theAlleles)){
    alleleName <- gsub("\\*", "_", nm)
    fileNm <- paste(alleleName, "Pep", sep = "")
    rValueFile <- paste(alleleName, "rValue", sep = "")
    predictedFile <- paste(alleleName, "myPredict.txt", sep = "")
    outputFile <- paste(alleleName, "Output.txt", sep = "")
    checkList <- paste(alleleName, "Check.txt", sep = "")
    NielsenPredict <- paste(alleleName, "Nielsen.txt", sep = "")

    str <- nm
    #now do checking
    #checking length
    peptidelist <- newData$peptide.list[(names(newData$allele.list)==nm) & longEnough]
    rValuelist <- newData$rValue[(names(newData$allele.list)==nm) & longEnough]
    my.predictList <- report$predicted[(names(newData$allele.list)==nm) & longEnough]
    N.check <- as.matrix(read.table(checkList)); dim(N.check) <- NULL
    N.predict <- as.double(as.matrix(read.table(NielsenPredict))); dim(N.predict) <- NULL
    print(paste("safetyIndex: ", min(N.predict)))
    N.predict <- 1-log(N.predict)/log(15000)
    N.predict[N.predict > 1] <- 1; N.predict[N.predict < 0] <- 0

    if(length(N.check) != length(peptidelist)) warning("length(N.check) != length(peptidelist)")
    if(length(peptidelist) != length(rValuelist)) warning("length(peptidelist) != length(rValuelist)")
    if(length(N.check) != length(my.predictList)) warning("length(N.check) != length(my.predictList)")
    if(length(N.predict) != length(N.check)) warning("length(N.predict) != length(N.check)")
    if(sum(peptidelist != N.check) > 0.5) warning("sum(peptidelist != N.check) > 0.5")

    #computing everything
    weights[nm] <- length(N.check)
    auc.me <- getAUC.guoxin(predicted = my.predictList, realValue = rValuelist)
    auc.N <- getAUC.guoxin(predicted = N.predict, realValue = rValuelist)
    rmse.me <- getRMSE(predicted = my.predictList, realValue = rValuelist)
    rmse.N <- getRMSE(predicted = N.predict, realValue = rValuelist)

    w.rmse.me <- w.rmse.me + rmse.me * weights[nm]
    w.auc.me  <- w.auc.me  + auc.me * weights[nm]
    a.rmse.me <- a.rmse.me + rmse.me
    a.auc.me  <- a.auc.me  + auc.me

    w.rmse.N <- w.rmse.N + rmse.N * weights[nm]
    w.auc.N <- w.auc.N + auc.N * weights[nm]
    a.rmse.N <- a.rmse.N + rmse.N
    a.auc.N <- a.auc.N + auc.N

    str <- paste(str, length(N.check), f(rmse.me), f(auc.me), f(rmse.N), f(auc.N), sep = " & ")
    str <- paste(str, "\\\\")
    write(str, file = "midCodes.txt", append = "T")
}
disp <- function(st){ print(paste(st,":", get(st))) }

w.rmse.me <- w.rmse.me / sum(weights)
w.auc.me  <- w.auc.me  / sum(weights)
a.rmse.me <- a.rmse.me / length(theAlleles)
a.auc.me  <- a.auc.me  / length(theAlleles)
                       
w.rmse.N <- w.rmse.N   / sum(weights)
w.auc.N <- w.auc.N     / sum(weights)
a.rmse.N <- a.rmse.N   / length(theAlleles)
a.auc.N <- a.auc.N     / length(theAlleles)
                        
disp("w.rmse.me")
disp("w.auc.me")
disp("a.rmse.me")
disp("a.auc.me")

disp("w.rmse.N")
disp("w.auc.N")
disp("a.rmse.N")
disp("a.auc.N")
#results;
#   [1] "safetyIndex:  1.74"
#   [1] "safetyIndex:  2.25"
#   [1] "safetyIndex:  6.1"
#   [1] "safetyIndex:  3.99"
#   [1] "safetyIndex:  3.43"
#   [1] "safetyIndex:  164.7"
#   [1] "safetyIndex:  11.9"
#   [1] "safetyIndex:  3.71"
#   [1] "safetyIndex:  3.71"
#   [1] "safetyIndex:  28.01"
#   [1] "safetyIndex:  2.07"
#   [1] "safetyIndex:  17.31"
#   [1] "safetyIndex:  15.05"
#   [1] "safetyIndex:  4.59"
#   [1] "safetyIndex:  8.02"
#   [1] "safetyIndex:  4"
#   [1] "safetyIndex:  4.79"
#   [1] "safetyIndex:  1.79"
#   [1] "safetyIndex:  4.63"
#   [1] "safetyIndex:  6.8"
#   [1] "safetyIndex:  4.97"
#   [1] "safetyIndex:  25.85"
#   [1] "safetyIndex:  104.73"
#   [1] "safetyIndex:  12.2"
#   [1] "safetyIndex:  9.31"
#   [1] "safetyIndex:  7.86"
#   [1] "safetyIndex:  4.14"
#   [1] "safetyIndex:  2.17"
#   [1] "safetyIndex:  5.64"
#   [1] "w.rmse.me : 0.218532391611024"
#   [1] "w.auc.me : 0.803088364036335"
#   [1] "a.rmse.me : 0.240458480197864"
#   [1] "a.auc.me : 0.769872203342283"
#   [1] "w.rmse.N : 0.218156011317848"
#   [1] "w.auc.N : 0.822159287189972"
#   [1] "a.rmse.N : 0.259470465724132"
#   [1] "a.auc.N : 0.771512664795028"
